select max(id) AS id,max(name) AS name,max(location) AS location
from Q4_data

select min(id) AS id,max(name) AS name,max(location) AS location
from Q4_data